from pymatgen.core import Structure
from pymatgen.io.vasp.inputs import Kpoints

def kpoints_by_kppra(s: Structure, kppra:int=2000, gamma=True):
    v=max(1e-6, s.volume); n=max(1,len(s)); m=max(2,int(round((kppra*n/v)**(1/3))))
    return Kpoints(comment=f'KPPRA {kppra}', style='Gamma' if gamma else 'Monkhorst', kpts=[[m,m,m]])
