import re, json, shutil
from pathlib import Path
import yaml
ALT_SUFFIX=['','_pv','_sv','_h','_d']
def ensure_parent(p:Path): p.parent.mkdir(parents=True, exist_ok=True)
def write_text(p:Path,s:str): ensure_parent(p); p.write_text(s,encoding='utf-8')
def find_potcar_for_element(root:Path, sym:str)->Path:
    for suf in ALT_SUFFIX:
        p=root/(sym+suf)/'POTCAR'
        if p.exists(): return p
    raise FileNotFoundError(f'POTCAR for {sym} not under {root}')
def make_potcar(structure, root:Path, out:Path, cache_dir:Path=None):
    syms=[sp.symbol for sp in structure.composition.elements]
    key='_'.join(sorted(syms))
    if cache_dir:
        cached=cache_dir/key/'POTCAR'
        if cached.exists(): ensure_parent(out); shutil.copy(cached,out); return syms
    parts=[find_potcar_for_element(root,s) for s in syms]
    ensure_parent(out)
    with open(out,'wb') as fo:
        for p in parts: fo.write(open(p,'rb').read())
    if cache_dir:
        ensure_parent(cache_dir/key/'POTCAR'); shutil.copy(out, cache_dir/key/'POTCAR')
    write_text(out.with_suffix('.used.json'), json.dumps([{'element':s,'path':str(find_potcar_for_element(root,s))} for s in syms], indent=2))
    return syms
def get_max_enmax(p:Path)->float:
    txt=p.read_text(errors='ignore'); vals=[float(x) for x in re.findall(r'ENMAX\s*=\s*([0-9.]+)', txt)]
    return max(vals) if vals else 520.0
def render_pbs(cfg, workdir:Path, out:Path):
    t=(workdir.parent/'templates'/'PBS.run_all_progress.template.pbs')
    if not t.exists(): t=Path('templates')/'PBS.run_all_progress.template.pbs'
    s=t.read_text(); s=(s.replace('{{ACCOUNT}}',str(cfg.get('pbs',{}).get('account','YOUR_ACCOUNT')))        .replace('{{QUEUE}}',str(cfg.get('pbs',{}).get('queue','batch')))        .replace('{{NODES}}',str(cfg.get('pbs',{}).get('nodes_per_job',1)))        .replace('{{PPN}}',str(cfg.get('pbs',{}).get('ppn',16)))        .replace('{{WALLTIME}}',f"{int(cfg.get('pbs',{}).get('walltime_hours',48)):02d}:00:00")        .replace('{{VASP_EXE}}',str(cfg.get('vasp',{}).get('exe','vasp_std'))))
    write_text(out, s)

def kppra_for_mode(cfg, mode:str)->int:
    r=cfg.get('run',{}); return int(r.get('kppra_screen' if mode=='screen' else 'kppra_prod',2000))

def encut_for_mode(cfg, potcar_path:Path, mode:str)->float:
    enmax=get_max_enmax(potcar_path); r=cfg.get('run',{})
    buf=float(r.get('encut_buffer_screen' if mode=='screen' else 'encut_buffer_prod',1.0))
    return round(enmax*buf,1)
