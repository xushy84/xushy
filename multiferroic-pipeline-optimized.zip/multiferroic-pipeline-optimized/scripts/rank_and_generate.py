import argparse, subprocess, pathlib, pandas as pd

def score_row(r):
    s=0.0; s+=2.0 if bool(r.get('multiferroic_candidate',False)) else 0.0
    s+=0.5 if bool(r.get('has_heavy_elem',False)) else 0.0
    s+=0.5 if bool(r.get('noncentrosymm',False)) else 0.0
    n=max(1,int(r.get('nsites',1))); s+=1.0/(1+0.02*n); return s

def main():
    p=argparse.ArgumentParser(); p.add_argument('--csv',required=True); p.add_argument('--top',type=int,default=30); p.add_argument('--out-csv',default='results/ranked_candidates.csv'); p.add_argument('--cif-dir'); p.add_argument('--workdir'); p.add_argument('--potcar-dir',required=True); p.add_argument('--config',required=True); a=p.parse_args()
    df=pd.read_csv(a.csv); 
    if 'score' not in df.columns: df['score']=df.apply(score_row, axis=1)
    df=df.sort_values('score', ascending=False).reset_index(drop=True)
    top=df.head(a.top).copy(); pathlib.Path(a.out_csv).parent.mkdir(parents=True, exist_ok=True); top.to_csv(a.out_csv,index=False); print('Wrote', a.out_csv)
    if a.workdir and a.cif_dir:
        idxs=",".join(str(int(i)) for i in top['index'].tolist())
        cmd=['python','-m','scripts.submit_vasp','--cif-dir',a.cif_dir,'--potcar-dir',a.potcar_dir,'--config',a.config,'--workdir',a.workdir,'--indices',idxs,'--stages','stage1_relax,stage2_static']
        print('Calling:', ' '.join(cmd)); subprocess.check_call(cmd)
if __name__=='__main__': main()
