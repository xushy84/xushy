import argparse, pathlib, yaml
from pathlib import Path
from pymatgen.core import Structure
from tools.gen_kpoints import kpoints_by_kppra
from scripts.utils_vasp import make_potcar, encut_for_mode, kppra_for_mode, write_text
STAGES_ALL=['stage1_relax','stage2_static','stage3_dos','stage4_band','stage5_soc_001','stage5_soc_010','stage5_soc_100','stage6_berry']

def load_cfg(p): return yaml.safe_load(open(p))

def write_stage(root: Path, s: Structure, stage: str, cfg, potcar_dir: Path):
    root.mkdir(parents=True, exist_ok=True); s.to(fmt='poscar', filename=str(root/'POSCAR'))
    cache_dir=Path('work/potcar_cache'); make_potcar(s, Path(potcar_dir), root/'POTCAR', cache_dir=cache_dir)
    mode='screen' if stage in ('stage1_relax','stage2_static') else 'prod'
    encut=encut_for_mode(cfg, root/'POTCAR', mode); ispin=2
    map={'stage1_relax':'templates/INCAR.stage1.screen','stage2_static':'templates/INCAR.stage2.screen','stage3_dos':'templates/INCAR.stage3.prod','stage6_berry':'templates/INCAR.stage6.berry.prod'}
    tpl_path=Path(map.get(stage,'templates/INCAR.stage2.screen')).read_text()
    if '{ENCUT_HIGH}' in tpl_path:
        encut_high=encut_for_mode(cfg, root/'POTCAR','prod'); tpl_path=tpl_path.replace('{ENCUT_HIGH}',f'{encut_high:.1f}')
    tpl_path=tpl_path.replace('{ENCUT}',f'{encut:.1f}').replace('{ISPIN}',str(ispin)); write_text(root/'INCAR', tpl_path)
    kppra=kppra_for_mode(cfg, mode); kp=kpoints_by_kppra(s, kppra=kppra, gamma=True); write_text(root/'KPOINTS', kp.__str__())

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--cif-dir',required=True); ap.add_argument('--potcar-dir',required=True); ap.add_argument('--config',required=True); ap.add_argument('--workdir',default='work/vasp_runs'); ap.add_argument('--limit',type=int,default=0); ap.add_argument('--stages',default='all'); ap.add_argument('--indices',default=None); a=ap.parse_args()
    cfg=load_cfg(a.config); cif_root=Path(a.cif_dir); work=Path(a.workdir); work.mkdir(parents=True, exist_ok=True)
    files=sorted(cif_root.glob('**/*.cif'))
    if a.limit>0: files=files[:a.limit]
    req=STAGES_ALL if a.stages=='all' else [s.strip() for s in a.stages.split(',')]
    idx_set=set([x.strip() for x in a.indices.split(',')]) if a.indices else None
    for idx,f in enumerate(files):
        if idx_set and (str(idx) not in idx_set and f.name not in idx_set): continue
        s=Structure.from_file(str(f)); gen=work/f'gen_{idx}'
        for st in req: write_stage(gen/st, s, st, cfg, Path(a.potcar_dir))
    print('Done.')
if __name__=='__main__': main()
