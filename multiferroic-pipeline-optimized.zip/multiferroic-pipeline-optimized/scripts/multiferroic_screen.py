import argparse, pandas as pd, pathlib
LONE=set('Bi Pb Te Se Sb Sn I'.split()); HEAVY=set('Bi Pb I Hg Pt Au W Ta Re Tl Sb'.split()).union(LONE)

def main():
    p=argparse.ArgumentParser(); p.add_argument('--cif-dir',required=True); p.add_argument('--out',required=True); p.add_argument('--merge-all-screen',action='store_true'); p.add_argument('--all-screen',default='results/all_screen.csv'); a=p.parse_args()
    df=pd.read_csv(a.all_screen)
    def has_any(f,grp):
        els=[t for t in str(f).replace('(',' ').replace(')',' ').split()]; return any(e in grp for e in els)
    df['has_lonepair_elem']=df['formula'].apply(lambda x: has_any(x,LONE))
    df['has_heavy_elem']=df['formula'].apply(lambda x: has_any(x,HEAVY))
    df['multiferroic_candidate']=(df['noncentrosymm'] | df['has_lonepair_elem']) & df['has_mag_elem']
    out=df[['index','cif_name','formula','nsites','density','spg','noncentrosymm','has_mag_elem','has_lonepair_elem','has_heavy_elem','multiferroic_candidate']]
    pathlib.Path('results').mkdir(parents=True, exist_ok=True); out.to_csv(a.out,index=False)
    if a.merge_all_screen: out.to_csv('results/all_screen_with_multiferroic.csv', index=False)
    print('Wrote', a.out)
if __name__=='__main__': main()
