import argparse, csv, pathlib
from tqdm import tqdm
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
MAG_ELEMS=set('V Cr Mn Fe Co Ni Gd Tb Dy Ho Er Tm Yb Ce Pr Nd Eu'.split())

def main():
    p=argparse.ArgumentParser(); p.add_argument('--cif-dir',required=True); p.add_argument('--out',required=True); p.add_argument('--limit',type=int,default=0); a=p.parse_args()
    root=pathlib.Path(a.cif_dir); files=sorted(root.glob('**/*.cif'))
    if a.limit>0: files=files[:a.limit]
    rows=[]
    for i,f in enumerate(tqdm(files, desc='scan CIF')):
        try:
            s=Structure.from_file(str(f)); sg=SpacegroupAnalyzer(s, symprec=1e-3); ds=sg.get_symmetry_dataset()
            noncent=not ds.get('has_inversion',False); els=[el.symbol for el in s.composition.elements]
            rows.append(dict(index=i,cif_name=f.name,cif_path=str(f),formula=str(s.composition.reduced_formula),nsites=len(s),density=round(s.density,3),spg=ds.get('international','?'),noncentrosymm=noncent,has_mag_elem=any(e in MAG_ELEMS for e in els)))
        except Exception:
            rows.append(dict(index=i,cif_name=f.name,cif_path=str(f),formula='PARSE_FAIL',nsites=0,density=0,spg='?',noncentrosymm=False,has_mag_elem=False))
    pathlib.Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    with open(a.out,'w',newline='') as fo:
        w=csv.DictWriter(fo, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
    print(f'Wrote {a.out} ({len(rows)} rows)')
if __name__=='__main__': main()
