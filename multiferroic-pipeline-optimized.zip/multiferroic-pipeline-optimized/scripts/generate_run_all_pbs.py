import argparse, yaml, pathlib
from scripts.utils_vasp import render_pbs

def main():
    p=argparse.ArgumentParser(); p.add_argument('--config',required=True); p.add_argument('--workdir',required=True); p.add_argument('--out',default='run_all_progress.pbs'); a=p.parse_args()
    cfg=yaml.safe_load(open(a.config)); workdir=pathlib.Path(a.workdir); out=workdir/a.out; render_pbs(cfg, workdir, out); print('Wrote', out)
if __name__=='__main__': main()
